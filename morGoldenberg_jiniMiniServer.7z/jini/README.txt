to start the server:
1. open cmd
2. enter "java -jar runJini.jar"

to close the server:
at the command line enter Ctrl+C

client side:
welcome url: <URL>:<PORT>/welcome